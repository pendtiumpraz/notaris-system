# 📊 OPEX & Pricing - Sistem Portal Klien Notaris

> **Dokumen Kalkulasi Biaya Operasional dan Struktur Harga**
> Disusun: 9 Desember 2025

---

## 🎯 Ringkasan Eksekutif

| Model | Harga |
|-------|-------|
| **SaaS (Subscription)** | Rp 1.500.000 - Rp 3.000.000/bulan |
| **License (One-Time)** | Rp 25.000.000 - Rp 75.000.000 |
| **OPEX Infrastruktur** | Rp 450.000 - Rp 950.000/bulan |

---

## 🔄 Model Bisnis: SaaS vs License

### 📱 Model SaaS (Software as a Service)

**Konsep:** Notaris bayar bulanan, kita yang urus semuanya.

| Paket | Harga/Bulan | Termasuk |
|-------|-------------|----------|
| **Starter** | Rp 1.500.000 | 1 Admin, 3 Staff, 100 Klien, 15GB |
| **Professional** | Rp 2.500.000 | 3 Admin, 10 Staff, 500 Klien, 45GB |
| **Enterprise** | Rp 4.000.000 | Unlimited, Custom branding, Priority |

**Keuntungan SaaS:**
- ✅ Recurring revenue (pendapatan bulanan tetap)
- ✅ Semua di-manage kita (VPS, DB, backup)
- ✅ Update & maintenance otomatis
- ✅ Barrier to entry rendah untuk notaris

**Margin SaaS:**
| Paket | Harga Jual | OPEX | Profit/Klien |
|-------|------------|------|--------------|
| Starter | Rp 1.500.000 | Rp 150.000* | **Rp 1.350.000** |
| Professional | Rp 2.500.000 | Rp 200.000* | **Rp 2.300.000** |
| Enterprise | Rp 4.000.000 | Rp 300.000* | **Rp 3.700.000** |

*\*OPEX per klien jika hosting 10+ klien di satu server*

---

### 📜 Model License (One-Time Purchase)

**Konsep:** Notaris beli putus, hosting sendiri atau beli terpisah.

| Tier | Harga License | Termasuk |
|------|---------------|----------|
| **Basic** | Rp 25.000.000 | Source code, 1 domain, 3 bulan support |
| **Professional** | Rp 45.000.000 | + Unlimited domain, 6 bulan support, training |
| **Enterprise** | Rp 75.000.000 | + White-label, 12 bulan support, custom feature |

**Biaya Tambahan License:**
| Item | Harga |
|------|-------|
| Maintenance Tahunan | Rp 5.000.000/tahun (setelah masa support) |
| Hosting (by us) | Rp 750.000/bulan |
| Setup & Instalasi | Rp 2.500.000 (one-time) |
| Training (4 jam) | Rp 1.000.000 |
| Custom Feature | Rp 2.000.000 - 10.000.000/fitur |

**Proyeksi License + Hosting:**
```
Tahun 1:
  License Professional    Rp 45.000.000
  Hosting 12 bulan       Rp  9.000.000
  Setup                  Rp  2.500.000
  ─────────────────────────────────────
  Total                  Rp 56.500.000

Tahun 2+:
  Maintenance            Rp  5.000.000
  Hosting 12 bulan       Rp  9.000.000
  ─────────────────────────────────────
  Total                  Rp 14.000.000/tahun
```

---

### ⚖️ Perbandingan SaaS vs License

| Aspek | SaaS | License |
|-------|------|---------|
| **Modal awal notaris** | Rendah (Rp 1.5jt) | Tinggi (Rp 25-75jt) |
| **Pendapatan kita** | Recurring bulanan | Lump sum + maintenance |
| **Revenue 3 tahun** | Rp 54jt+ per klien | Rp 56.5jt + Rp 28jt = Rp 84.5jt |
| **Control notaris** | Rendah | Tinggi (punya source) |
| **Risiko churn** | Ada | Tidak ada |
| **Scalability** | Mudah | Perlu negosiasi ulang |
| **Target market** | Notaris kecil-menengah | Notaris besar, multi-cabang |

---

### 🎯 Rekomendasi Model Bisnis

**Untuk Agen:**
1. **Jual SaaS** ke notaris kecil-menengah
2. **Jual License** ke notaris besar atau yang mau hosting sendiri
3. **Hybrid**: Tawarkan keduanya, biar notaris pilih

**Pricing Strategy:**
```
SaaS Professional 2 tahun   = Rp 2.5jt × 24 = Rp 60.000.000
License Professional        = Rp 45.000.000 + Rp 14jt = Rp 59.000.000

→ Hampir sama! Tapi SaaS = recurring, License = upfront cash
```

---

## 📦 Fitur Sistem yang Termasuk

### Core Features
- ✅ Multi-role User Management (Super Admin, Admin, Staff, Client)
- ✅ Document Management dengan Google Drive Integration
- ✅ Appointment Scheduling System
- ✅ Real-time Messaging
- ✅ Notification System (Email, Push)
- ✅ Audit Logging & Security
- ✅ CMS (FAQ, Testimonial, Team, Gallery)
- ✅ Branch Management (Multi-cabang)

### Tech Stack
- **Frontend**: Next.js 16, React 19, TailwindCSS 4
- **Backend**: Next.js API Routes
- **Database**: PostgreSQL
- **Auth**: NextAuth.js
- **Storage**: Google Drive Integration (FREE!)

---

## 💰 Breakdown OPEX Bulanan

### Opsi 1: Budget Minimum (Single Client) 
**Total: ~Rp 450.000/bulan**

| Komponen | Spesifikasi | Biaya/Bulan |
|----------|-------------|-------------|
| VPS | 2 vCPU, 4GB RAM, 80GB SSD | Rp 200.000 |
| PostgreSQL | Internal di VPS | Rp 0 |
| Domain | .com atau .co.id | Rp 15.000* |
| SSL | Let's Encrypt (Free) | Rp 0 |
| Email Server | Zoho Free / Gmail | Rp 0 |
| Google Drive | Account notaris (gratis 15GB) | Rp 0 |
| Cadangan & Maintenance | Buffer | Rp 50.000 |
| **TOTAL** | | **Rp 265.000** |

*\*Domain dibayar tahunan ~Rp 180.000, dibagi 12 bulan*

---

### Opsi 2: Standard (1-3 Klien Notaris)
**Total: ~Rp 550.000/bulan**

| Komponen | Spesifikasi | Biaya/Bulan |
|----------|-------------|-------------|
| VPS | 4 vCPU, 8GB RAM, 160GB SSD | Rp 400.000 |
| PostgreSQL | Managed (Neon/Supabase Free tier) | Rp 0 |
| Domain | Per notaris | Rp 15.000 |
| SSL | Let's Encrypt (Free) | Rp 0 |
| Backup | Weekly backup | Rp 50.000 |
| Monitoring | Uptime Robot (Free) | Rp 0 |
| Google Drive | Per notaris | Rp 0 |
| **TOTAL** | | **Rp 465.000** |

---

### Opsi 3: Premium (Scale Ready)
**Total: ~Rp 950.000/bulan**

| Komponen | Spesifikasi | Biaya/Bulan |
|----------|-------------|-------------|
| VPS | 8 vCPU, 16GB RAM, 320GB SSD | Rp 750.000 |
| PostgreSQL | Managed DB (Supabase Pro) | Rp 0 - 400.000 |
| Domain | Custom | Rp 15.000 |
| SSL | Let's Encrypt | Rp 0 |
| CDN | Cloudflare (Free) | Rp 0 |
| Backup | Daily auto-backup | Rp 100.000 |
| Monitoring | 24/7 monitoring | Rp 50.000 |
| **TOTAL** | | **Rp 915.000** |

---

## 🏢 Rekomendasi VPS Provider (Indonesia)

| Provider | Spesifikasi | Harga/Bulan | Keterangan |
|----------|-------------|-------------|------------|
| **IDCloudHost** | 4 vCPU, 8GB RAM | Rp 350.000 | Murah, server Jakarta |
| **Dewaweb** | 4 vCPU, 8GB RAM | Rp 400.000 | Support bagus |
| **Niagahoster** | VPS KVM 4GB | Rp 300.000 | Promo sering |
| **DigitalOcean** | 4GB/2vCPU | ~Rp 400.000 | Stabil, global |
| **Vultr** | 4GB/2vCPU | ~Rp 350.000 | Lokasi Singapore |
| **Contabo** | 8GB/4vCPU | ~Rp 150.000 | Murah, EU server |

---

## 💵 Struktur Harga Jual

### Ke Agen Reseller

| Tier | OPEX Basis | Margin Agen | Harga ke Agen |
|------|------------|-------------|---------------|
| **Basic** | Rp 450.000 | +Rp 300.000 | **Rp 750.000/bln** |
| **Standard** | Rp 550.000 | +Rp 450.000 | **Rp 1.000.000/bln** |
| **Premium** | Rp 950.000 | +Rp 550.000 | **Rp 1.500.000/bln** |

---

### Ke Notaris (End User)

| Tier | Harga Agen | Margin Agen → Notaris | Harga Final |
|------|------------|----------------------|-------------|
| **Basic** | Rp 750.000 | +Rp 750.000 (100%) | **Rp 1.500.000/bln** |
| **Standard** | Rp 1.000.000 | +Rp 1.000.000 (100%) | **Rp 2.000.000/bln** |
| **Premium** | Rp 1.500.000 | +Rp 1.500.000 (100%) | **Rp 3.000.000/bln** |

---

## 📋 Paket Subscription untuk Notaris

### 🥉 Paket Bronze - Rp 1.500.000/bulan
- 1 Admin + 3 Staff + 100 Klien
- 15GB Storage (Google Drive)
- Email notifications
- Support via WhatsApp (jam kerja)
- Maintenance bulanan

### 🥈 Paket Silver - Rp 2.000.000/bulan
- 2 Admin + 10 Staff + 500 Klien
- 30GB Storage (2 Google Drive)
- Email + Push notifications
- Priority WhatsApp support
- Weekly backup
- Maintenance bulanan

### 🥇 Paket Gold - Rp 3.000.000/bulan
- 5 Admin + Unlimited Staff + Unlimited Klien
- 75GB+ Storage (5 Google Drive)
- Email + Push + SMS notifications
- 24/7 Priority support
- Daily backup
- Maintenance mingguan
- Custom branding

---

## 💼 Biaya Tambahan (Opsional)

| Item | Biaya |
|------|-------|
| Setup & Instalasi | Rp 2.500.000 (one-time) |
| Training 2 jam | Rp 500.000 |
| Custom Domain Setup | Rp 250.000 |
| Migrasi Data | Rp 1.000.000 - 3.000.000 |
| Custom Feature | Rp 500.000 - 5.000.000/fitur |
| Maintenance On-call | Rp 500.000/bulan |

---

## 📊 Proyeksi Keuntungan Agen

### Skenario: 10 Klien Notaris (Paket Silver)

| Item | Kalkulasi |
|------|-----------|
| **Pendapatan** | 10 × Rp 2.000.000 = Rp 20.000.000 |
| **Bayar ke Developer** | 10 × Rp 1.000.000 = Rp 10.000.000 |
| **OPEX Infrastruktur** | 1 VPS shared = Rp 750.000 |
| **Gross Profit** | **Rp 9.250.000/bulan** |

### Skenario: 5 Klien (Mixed Tier)

| Paket | Jumlah | Pendapatan | Biaya ke Dev |
|-------|--------|------------|--------------|
| Bronze | 2 | Rp 3.000.000 | Rp 1.500.000 |
| Silver | 2 | Rp 4.000.000 | Rp 2.000.000 |
| Gold | 1 | Rp 3.000.000 | Rp 1.500.000 |
| **Total** | 5 | **Rp 10.000.000** | **Rp 5.000.000** |
| **Net Profit** | | | **Rp 5.000.000/bln** |

---

## 🔧 Konfigurasi Deployment Rekomendasi

```
┌─────────────────────────────────────────────────────────┐
│                    ARSITEKTUR SISTEM                    │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌─────────────┐     ┌─────────────┐                   │
│  │   Notaris   │     │   Notaris   │ ... (N clients)  │
│  │   Portal 1  │     │   Portal 2  │                   │
│  └──────┬──────┘     └──────┬──────┘                   │
│         │                   │                           │
│         └─────────┬─────────┘                           │
│                   │                                     │
│         ┌─────────▼─────────┐                          │
│         │   NGINX Reverse   │                          │
│         │      Proxy        │                          │
│         └─────────┬─────────┘                          │
│                   │                                     │
│    ┌──────────────┼──────────────┐                     │
│    │              │              │                     │
│    ▼              ▼              ▼                     │
│ ┌──────┐     ┌──────┐     ┌──────────┐                │
│ │Next.js│    │Next.js│    │PostgreSQL│                │
│ │ App 1 │    │ App 2 │    │    DB    │                │
│ └──────┘     └──────┘     └──────────┘                │
│                                                         │
│         ┌─────────────────────┐                        │
│         │   Google Drive(s)   │                        │
│         │   Document Storage  │                        │
│         └─────────────────────┘                        │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## ⚠️ Catatan Penting

> [!IMPORTANT]
> - Harga VPS bisa berubah sesuai provider dan promo
> - Google Drive gratis hanya 15GB per akun, bisa ditambah akun
> - Untuk SMS notification, perlu integrasi pihak ketiga (~Rp 500/SMS)
> - Maintenance rutin sangat penting untuk keamanan

> [!TIP]
> - Gunakan 1 VPS untuk multiple notaris (multi-tenant) untuk efisiensi
> - Negosiasi harga VPS tahunan bisa dapat diskon 20-30%
> - Pakai Cloudflare untuk CDN dan DDoS protection gratis

---

## ✅ Kesimpulan

**Rekomendasi untuk mulai:**
1. Start dengan VPS **Rp 400.000/bulan** (4GB RAM)
2. Jual paket **Silver Rp 2.000.000/bulan** ke notaris
3. **Margin bersih Rp 1.000.000-1.500.000** per klien
4. Target 5-10 klien = **Rp 5.000.000-15.000.000/bulan profit**

---

*Dokumen ini dibuat berdasarkan analisis sistem client-portal dan estimasi harga pasar Indonesia per Desember 2025.*
